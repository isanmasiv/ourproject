     <div class="panel panel-primary">
                        <div class="panel-heading">
                            <h3 class="panel-title">Panel title2</h3>
                        </div>
                        <div class="panel-body">
                            <div class="nano-content">
                                <ul class="gw-nav gw-nav-list">
                                    <li class="init-active">
                                         <a href="http://localhost:81/ci-blog/artikel.php/tutorial-asdsa-5#"> <span class="gw-menu-text">Nasvigation Menu</span> </a>
                                    </li>
                                    <li class="init-arrow-down">
                                        <a href="javascript:void(0)"> <span class="gw-menu-text">Category 1</span> <b class="gw-arrow"></b> </a>
                                        <ul class="gw-submenu">
                                            <li>
                                                <a href="javascript:void(0)">Menu 1</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="init-arrow-down">
                                        <a href="javascript:void(0)"> <span class="gw-menu-text">Category 2</span> <b class="gw-arrow icon-arrow-up8"></b> </a>
                                        <ul class="gw-submenu">
                                            <li>
                                                <a href="javascript:void(0)">Menu 1</a>
                                            </li>
                                            <li>
                                                <a href="javascript:void(0)">Menu 2</a>
                                            </li>
                                            <li>
                                                <a href="javascript:void(0)">Menu 3</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="init-arrow-down">
                                        <a href="javascript:void(0)"> <span class="gw-menu-text">Category 3</span> <b></b> </a>
                                        <ul class="gw-submenu">
                                            <li>
                                                <a href="javascript:void(0)">Menu 1</a>
                                            </li>
                                            <li>
                                                <a href="javascript:void(0)">Menu 2</a>
                                            </li>
                                            <li>
                                                <a href="javascript:void(0)">Menu 3</a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>    


					<div class="panel panel-primary">
                        <div class="panel-heading">
                            <h3 class="panel-title">Panel title</h3>
                        </div>
                        <div class="panel-body">
                            <div class="nano-content">
                                <ul class="gw-nav gw-nav-list">
                                    <li class="init-un-active">
                                        <a href="javascript:void(0)"> <span class="gw-menu-text">Navigation Menu</span> </a>
                                    </li>
                                    <li class="init-arrow-down">
                                        <a href="javascript:void(0)"> <span class="gw-menu-text">Category 1</span> <b class="gw-arrow"></b> </a>
                                        <ul class="gw-submenu">
                                            <li>
                                                <a href="javascript:void(0)">Menu 1</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="init-arrow-down">
                                        <a href="javascript:void(0)"> <span class="gw-menu-text">Category 2</span> <b class="gw-arrow icon-arrow-up8"></b> </a>
                                        <ul class="gw-submenu">
                                            <li>
                                                <a href="javascript:void(0)">Menu 1</a>
                                            </li>
                                            <li>
                                                <a href="javascript:void(0)">Menu 2</a>
                                            </li>
                                            <li>
                                                <a href="javascript:void(0)">Menu 3</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="init-arrow-down">
                                        <a href="javascript:void(0)"> <span class="gw-menu-text">Category 3</span> <b></b> </a>
                                        <ul class="gw-submenu">
                                            <li>
                                                <a href="javascript:void(0)">Menu 1</a>
                                            </li>
                                            <li>
                                                <a href="javascript:void(0)">Menu 2</a>
                                            </li>
                                            <li>
                                                <a href="javascript:void(0)">Menu 3</a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
					
					
					 
                        
                        <div class="panel-body">
                         <!-- Begin: //adsensecamp.com/ -->
<script src="//adsensecamp.com/show/?id=sU%2F7NZkelrY%3D&cid=sO23aMPfjUo%3D&chan=nrBATrmjlGA%3D&type=5&title=3D81EE&text=000000&background=FFFFFF&border=000000&url=2BA94F" type="text/javascript">
</script>
<!-- End: //adsensecamp.com/ -->
                        </div>
 